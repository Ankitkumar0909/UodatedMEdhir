package com.example.backend.model;

public enum Role {
    SUPERADMIN,
    HRADMIN
}
